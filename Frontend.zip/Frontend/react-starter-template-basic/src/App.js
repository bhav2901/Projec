// import logo from './logo.svg';
// import './App.css';

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }

// export default App;


import React from "react";
import Sidebar from "./components/Sidebars/Sidebar";
import TopBlue from "./components/TopBlue";
import FilesPanel from "./components/Filespanel/FilesPanel";
import Downloads from "./components/Downloads";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Favorites from "./components/Favorites";

export default function App() {
  return (
    <div className="bg-light">
       {/* Page title (same as your HTML) */}
      <header className="py-2 text-center user-title">
        {/* <h1 className="mb-0">User Dashboard</h1> */}
        {/* <img src="sc.png" class="logo-img me-2"></img> */}
      </header>

      <div className="container-fluid px-4">
        <div className="row gx-3">
          {/* LEFT: Sidebar */}
                <Sidebar />
           
          {/* RIGHT: Main */}
          <main className="col-md-9 col-lg-10">
            <Navbar />
            <div className='container'>
              <BrowserRouter>
               <Routes>
                <Route path="/downloads" element={<Downloads />}></Route>
                <Route path="/favorites" element={<Favorites />}></Route>
               </Routes>
              </BrowserRouter>
            <TopBlue />
            <FilesPanel />
            </div>
          </main>
        </div>
      </div>
    </div>
    );
}
