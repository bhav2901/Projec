// import React from 'react';
// import { BrowserRouter, NavLink } from 'react-router-dom';
// import '../components/navbar.css';

// const Navbar = () => {
//   return (
//     <BrowserRouter>
//       <ul className="nav-links">
//         <li>
//           <NavLink to="/downloads" activeClassName="active">
//           {/* <button>View Downloads</button> */}
//           </NavLink>
//         </li>
//         <li>
//           <NavLink to="/favorites" activeClassName="active">
//             Favorites
//           </NavLink>
//         </li>
//       </ul>
//     </BrowserRouter>
//   );
// };

// export default Navbar;

// import React, { useState } from 'react';
// import { BrowserRouter, NavLink } from 'react-router-dom';
// import '../components/navbar.css';

// // ModalPopup component (can be in a separate file like modal_popup.jsx)
// const ModalPopup = ({ showModalPopup, onPopupClose, downloadLink }) => {
//   return (
//     <>
//       {showModalPopup && (
//         <div className="modal-overlay" onClick={() => onPopupClose(false)}>
//           <div className="modal-content" onClick={(e) => e.stopPropagation()}>
//             <h2>Download Options</h2>
//             <p>Choose your download option:</p>
//             <a href={downloadLink} download="your-file.pdf">
//               <button>Download File</button>
//             </a>
//             <button onClick={() => onPopupClose(false)}>Close</button>
//           </div>
//         </div>
//       )}
//     </>
//   );
// };

// export default Navbar;


import React, { useState } from 'react';
import { BrowserRouter, NavLink } from 'react-router-dom';
import '../components/navbar.css';

// ModalPopup component (can be in a separate file like modal_popup.jsx)
const ModalPopup = ({ showModalPopup, onPopupClose, downloadLink, popupContent }) => { // Added popupContent prop
  return (
    <>
      {showModalPopup && (
        <div className="modal-overlay" onClick={() => onPopupClose(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            {popupContent ? popupContent : ( // Conditional rendering of popupContent
              <>
                <h2>Download Options</h2>
                <p>Choose your download option:</p>
                <a href={downloadLink} download="your-file.pdf">
                  <button style={{borderWidth:1,padding:5,margin:10}}>Download File</button>
                </a>
                <button onClick={() => onPopupClose(false)} style={{borderWidth:2,width:450,display:'grid'}}>Close</button>
              </>
            )}
          </div>
        </div>
      )}
    </>
  );
};

const Navbar = () => {
  const [showDownloadPopup, setShowDownloadPopup] = useState(false);
  const [showFavoritesPopup, setShowFavoritesPopup] = useState(false); // New state for favorites popup

  const toggleDownloadPopup = () => {
    setShowDownloadPopup(!showDownloadPopup);
  };

  const toggleFavoritesPopup = () => { // New function to toggle favorites popup
    setShowFavoritesPopup(!showFavoritesPopup);
  };

  return (
    <BrowserRouter>
      <ul className="nav-links">
        <li>
          <NavLink to="/downloads" activeClassName="active">
            <button onClick={toggleDownloadPopup} style={{borderWidth:1,borderColor:'black'}}>Downloads</button>
          </NavLink>
        </li>
        <li>
          <NavLink to="/favorites" activeClassName="active">
            <button onClick={toggleFavoritesPopup} style={{borderWidth:1,borderColor:'black'}}>Favorites</button> {/* Added onClick handler */}
          </NavLink>
        </li>
      </ul>
      <ModalPopup
        showModalPopup={showDownloadPopup}
        onPopupClose={toggleDownloadPopup}
        downloadLink="/path/to/your-file.pdf" // Replace with your actual download link
      />
      {/* New ModalPopup for Favorites */}
      <ModalPopup 
        showModalPopup={showFavoritesPopup} 
        onPopupClose={toggleFavoritesPopup} 
        popupContent={ 
            <> 
                <h2>Your Favorites</h2> 
                <p>This is your list of favorite items!</p> 
                <button onClick={() => toggleFavoritesPopup()}>Close</button> 
            </> 
        } 
      /> 
    </BrowserRouter>
  );
};

export default Navbar;