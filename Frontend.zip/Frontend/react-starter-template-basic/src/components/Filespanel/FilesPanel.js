import React, { useMemo, useState } from "react";
import Dropdown from 'react-bootstrap/Dropdown';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../Filespanel/filespanel.css';

/** Demo data = exactly your initial JS array */
const initialFiles = [
  { title: "Account Statement -Jan 2025", type: "Pdf", date: "2025-01-20" },
  { title: "Monthly Report -Dec 2024", type: "Txt", date: "2024-12-31" },
  { title: "Loan Summary 2024", type: "Pdf",  date: "2024-11-12" },
  { title: "Credit Report -Oct", type: "Pdf", date: "2024-10-05" },
  { title: "Summary -Q3 2024", type: "docx", date: "2024-09-30" }
];

export default function FilesPanel() {
  const [query, setQuery] = useState("");
  const [sortAsc, setSortAsc] = useState(false); // matches currentSortAsc = false
  const [fav, setFav] = useState(false);
  const [typeFilter, setTypeFilter] = useState("All"); // New state for type filter, defaults to "All"
  
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
   
    let base = initialFiles; // Start with the initial files

    if (q) {
      base = base.filter(
          f =>
            f.title.toLowerCase().includes(q) ||
            f.type.toLowerCase().includes(q)
      );
    }
    if (typeFilter !== "All") {
      base = base.filter(f => f.type === typeFilter);
    }

    base.sort((a, b) => {
      const da = new Date(a.date);
      const db = new Date(b.date);
      return sortAsc ? da - db : db - da;
    });
   

    return base;
  }, [query, sortAsc, typeFilter]);

  const downloadOne = (file) => {
    alert("Downloaded: " + file.title);
    // In a real app, you would trigger an actual download here.
  };

  const downloadAll = () => {
    alert("Download all(demo).");
    // You can loop filtered.forEach(downloadOne) to simulate all.
  };

  return (
    <div className="card content-card shadow-sm">
      {/* Blue header strip with search + fav + download all */}
      <div className="card-header bg-primary text-white rounded-top d-flex align-items-center">
        <div className="flex-grow-1">
          <div className="search-pill" style={{color:"transparent",width:200}}>
            <div className="input-group">
              <span className="input-group-text border-25">
                <i className="bi bi-search" style={{color:"white"}}></i>
              </span>
              <input
                id="searchInput "
                type="search"
                className="form-control border-0"
                placeholder="Search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </div>
          </div>
        </div>

        <div className="ms-3 d-flex align-items-center gap-2">
          <button
            id="favBtn"
            className="btn btn-outline-light btn-sm" style={{borderColor:"white"}}
            onClick={() => setFav(v => !v)}
            title="Favorite"
          >
            <i className={`bi ${fav ? "bi-heart-fill" : "bi-heart"}`} style={{color:"white"}}></i>
          </button>
          <button
            id="downloadAll"
            className="btn btn-outline-light btn-sm" style={{borderColor:"white"}}
            onClick={downloadAll}
            title="Download all"
          >
            <i className="bi bi-download" style={{color:"white"}}></i>
          </button>
        </div>
      </div>

      <div className="card-body p-4">
        {/* folder header with Date sort toggle (Type label kept static to match UI) */}
        <div className="d-flex align-items-center mb-3">
          <i className="bi bi-folder2-open display-6 text-secondary me-2"></i>
          <h4 className="mb-0">General</h4>

        <div className="ms-auto d-flex align-items-center gap-2">
        {/* <div className="me-2"style={{ fontFamily: "Verdana, sans-serif",fontWeight:"initial" }}>Type <i className="bi bi-caret-down-fill small"></i></div> */}
        <Dropdown onSelect={(eventKey) => setTypeFilter(eventKey)}>
                    <Dropdown.Toggle variant="link" id="typeDropdown" className="p-0 text-decoration-none text-body"style={{ fontFamily: "Verdana, sans-serif" }} >
                        Type{/*} <i className="bi bi-caret-down-fill small"></i> */}
                    </Dropdown.Toggle>
                    <Dropdown.Menu >
                        <Dropdown.Item eventKey="All">All</Dropdown.Item>
                        <Dropdown.Item eventKey="Pdf">Pdf</Dropdown.Item>
                        <Dropdown.Item eventKey="Txt">Txt</Dropdown.Item>
                        <Dropdown.Item eventKey="docx">docx</Dropdown.Item>
                    </Dropdown.Menu>
                </Dropdown>
            <div style={{ fontFamily: "Verdana, sans-serif" }}>
              Date{" "}
              <button
                id="sortDateBtn"
                className="btn btn-link btn-sm p-0 ms-1"
                onClick={() => setSortAsc(v => !v)}
                title="Toggle date sort">
                <i className={`bi ${sortAsc ? "bi-caret-up-fill" : "bi-caret-down-fill"}`}></i>
              </button>
            </div>
          </div>
        </div>

        {/* table header */}
        {/* Replaced the div-based header with a table header */}
        <table className="table table-borderless table-sm mb-2">
          <thead>
            <tr className="small text-muted text-center">
              <th className="text-start ms-5" style={{ fontFamily: "Verdana, sans-serif" ,fontWeight:"bolder", width: "auto",textAlign:"right !important" }}>Title</th>
              <th style={{ fontFamily: "Verdana, sans-serif",fontWeight:"bold", width: "16.66%" }}>Type</th>
              <th style={{ fontFamily: "Verdana, sans-serif",fontWeight:"bold", width: "16.66%" }}>Date</th>
              <th className="text-end" style={{ width: "8.33%" }}></th>
            </tr>
          </thead>
        </table>

        {/* file list using table structure */}
        <div id="fileList" className="list-group mb-3">
          <table className="table table-hover table-sm">
            <tbody>
              {filtered.map((f, idx) => (
                <tr className="file-row" key={idx}>
                  <td style={{ width: "58.33%" }}>
                    <div className="d-flex align-items-center">
                      <div className="file-square me-2"></div>
                      <div>
                        <div>{f.title}</div>
                        <div className="small text-muted">{f.title}</div>
                      </div>
                    </div>
                  </td>
                  <td className="text-muted text-center" style={{ width: "30%" }}>{f.type}</td>
                  <td className="text-muted text-center" style={{ width: "100%"}}>{f.date}</td>
                  <td className="text-end" style={{ width: "8.33%" }}>
                    <button
                      className="download-circle"
                      onClick={() => downloadOne(f)}
                      title="Download"
                    >
                      <i className="bi bi-download"></i>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* pagination / page number (kept static 'page 1 ▸' like original) */}
        <div className="d-flex justify-content-end align-items-center small text-muted">
          <span className="me-2">page</span>
          <span className="page-pill">1</span>
          <button className="btn btn-link btn-sm p-0 ms-2" title="Next page">
            <i className="bi bi-chevron-right"></i>
          </button>
        </div>
      </div>
    </div>
  );
}


