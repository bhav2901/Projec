// import React from 'react'

// function Favorites() {
//   return (
//     <h5>No Favorites yet.</h5>
//   )
// }

// export default Favorites;

import React, { useState, useEffect } from 'react';
// import "../components/downloads.css";

function Favorites() {
  const [showModal, setShowModal] = useState(false);
  const [downloads, setDownloads] = useState([]); // Imagine this would come from an API or other source

  const handleOpenModal = () => {
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
  };

  // Close modal when clicking outside of it
  useEffect(() => {
    const handleOutsideClick = (event) => {
      if (showModal && event.target.closest('.modal-content') === null) {
        setShowModal(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
    };
  }, [showModal]); // Close modal when clicking outside of it
}

  export default Favorites;
