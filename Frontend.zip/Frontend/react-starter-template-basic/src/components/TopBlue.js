import React from "react";

export default function TopBlue() {
  // <TopBlue />
  const onLogout = () => alert("Logout.");
  const onFav = () => alert("Favorite clicked (demo).");
  const onDownloadAll = () => alert("Downloaded all (demo).");

  return (
    <div className="top-blue mb-2 rounded">
      <div className="container-fluid d-flex align-items-center justify-content-end">
        <div className="me-3 icon-btn" title="Notifications"><i className="bi bi-bell"></i></div>
        <div className="me-3 icon-btn" title="Messages"><i className="bi bi-envelope"></i></div>
        <div className="me-3 icon-btn" title="Profile"><i className="bi bi-person-circle"></i></div>
        <button onClick={onLogout} className="btn btn-dark btn-sm">Logout</button>
      </div>
    </div>
  );
}