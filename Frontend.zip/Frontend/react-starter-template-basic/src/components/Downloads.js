
import React, { useState, useEffect } from 'react';
import "../components/downloads.css";

function Downloads() {
  const [showModal, setShowModal] = useState(false);
  const [downloads, setDownloads] = useState([]); // Imagine this would come from an API or other source

  const handleOpenModal = () => {
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
  };

  // Close modal when clicking outside of it
  useEffect(() => {
    const handleOutsideClick = (event) => {
      if (showModal && event.target.closest('.modal-content') === null) {
        setShowModal(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
    };
  }, [showModal]); // Close modal when clicking outside of it

//   return (
//     <div>
//       <button onClick={handleOpenModal}>View Downloads</button>

//       {showModal && (
//         <div className="modal-overlay"> {/*  Overlay to capture clicks outside the modal */}
//           <div className="modal-content">
//             <div className="modal-header">
//               <h4>Downloads</h4>
//               <button className="close-button" onClick={handleCloseModal}>X</button>
//             </div>
//             <div className="modal-body">
//               {downloads.length === 0 ? (
//                 <p>No downloads available.</p>
//               ) : (
//                 <ul>
//                   {downloads.map((download, index) => (
//                     <li key={index}>{download.name}</li>
//                   ))}
//                 </ul>
//               )}
//             </div>
//           </div>
//         </div>
//       )}
//     </div>
//   );
}

export default Downloads;