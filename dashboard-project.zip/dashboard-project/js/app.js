// Demo data for file rows
const files = [
  { title: "Account Statement - Jan 2025", type: "PDF", date: "2025-01-20" },
  { title: "Monthly Report - Dec 2024", type: "XLSX", date: "2024-12-31" },
  { title: "Loan Summary 2024", type: "PDF", date: "2024-11-12" },
  { title: "Credit Report - Oct", type: "PDF", date: "2024-10-05" },
  { title: "Summary - Q3 2024", type: "DOCX", date: "2024-09-30" }
];

let currentSortAsc = false;

// render rows into #fileList
function renderRows(list = files) {
  const container = document.getElementById('fileList');
  container.innerHTML = '';
  list.forEach((f, idx) => {
    const div = document.createElement('div');
    div.className = 'file-row';
    div.innerHTML = `
      <div class="file-title">
        <div class="file-square"></div>
        <div>
          <div>${f.title}</div>
          <div class="small text-muted">${f.title.replace(/[^]/,'')}</div>
        </div>
      </div>
      <div class="text-muted">${f.type}</div>
      <div class="text-muted">${f.date}</div>
      <div class="text-end">
        <button class="download-circle" data-idx="${idx}" title="Download">
          <i class="bi bi-download"></i>
        </button>
      </div>
    `;
    container.appendChild(div);
  });

  // attach download handlers
  container.querySelectorAll('.download-circle').forEach(btn => {
    btn.addEventListener('click', e => {
      const i = e.currentTarget.getAttribute('data-idx');
      const item = files[i];
      alert('Download triggered for: ' + item.title);
      // in a real app you would trigger file download here
    });
  });
}

function initSearch() {
  const input = document.getElementById('searchInput');
  input.addEventListener('input', (e) => {
    const q = e.target.value.trim().toLowerCase();
    const filtered = files.filter(f => f.title.toLowerCase().includes(q) || f.type.toLowerCase().includes(q));
    renderRows(filtered);
  });
}

function initSort() {
  const btn = document.getElementById('sortDateBtn');
  btn.addEventListener('click', () => {
    currentSortAsc = !currentSortAsc;
    const sorted = [...files].sort((a,b) => {
      const da = new Date(a.date), db = new Date(b.date);
      return currentSortAsc ? da - db : db - da;
    });
    renderRows(sorted);
  });
}

function initSidebarToggles() {
  document.querySelectorAll('.btn-toggle').forEach(btn => {
    const target = document.querySelector(btn.getAttribute('data-target'));
    btn.addEventListener('click', () => {
      if (!target) return;
      const bsCollapse = bootstrap.Collapse.getOrCreateInstance(target, {toggle:true});
      bsCollapse.toggle();
    });
  });
}

function initTopButtons() {
  document.getElementById('logoutBtn').addEventListener('click', () => {
    alert('Logout clicked (demo).');
  });
  document.getElementById('downloadAll').addEventListener('click', () => {
    alert('Download all clicked (demo).');
  });
  document.getElementById('favBtn').addEventListener('click', () => {
    alert('Favorite clicked (demo).');
  });
}

// initialize
document.addEventListener('DOMContentLoaded', () => {
  renderRows();
  initSearch();
  initSort();
  initSidebarToggles();
  initTopButtons();
});
